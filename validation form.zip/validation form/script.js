const form = document.getElementById('validationForm');

form.addEventListener('submit', function (e) {
    e.preventDefault();

    // Clear previous error messages
    document.getElementById('nameError').textContent = '';
    document.getElementById('emailError').textContent = '';
    document.getElementById('phoneError').textContent = '';
    document.getElementById('passwordError').textContent = '';
    document.getElementById('confirmPasswordError').textContent = '';

    let hasError = false;

    // Full Name validation (must be at least 5 characters)
    const fullName = document.getElementById('fullName').value.trim();
    if (fullName.length < 5) {
        document.getElementById('nameError').textContent = 'Full name must be at least 5 characters long';
        hasError = true;
    }

      // Gender validation (must select an option)
    const gender = document.getElementById('gender').value;
    if (!gender) {
        document.getElementById('genderError').textContent = 'Please select your gender';
        hasError = true;
    }

    // Email validation (must contain @ character)
    const email = document.getElementById('email').value.trim();
    if (!email.includes('@')) {
        document.getElementById('emailError').textContent = 'Enter a valid email address';
        hasError = true;
    }

    // Phone number validation (must be 10 digits and not "123456789")
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const phonePattern = /^[0-9]{10}$/;
    if (!phonePattern.test(phoneNumber) || phoneNumber === "1234567890") {
        document.getElementById('phoneError').textContent = 'Enter a valid 10-digit phone number';
        hasError = true;
    }

    // Password validation (cannot be 'password', user's name, or less than 8 characters)
    const password = document.getElementById('password').value.trim();
    if (password.length < 8 || password.toLowerCase() === 'password' || password === fullName) {
        document.getElementById('passwordError').textContent = 'Password must be at least 8 characters and not "password" or your name';
        hasError = true;
        password.innerHTML = '<i class="fas fa-check-circle"></i>';
    }

    // Confirm password validation (must match the password)
    const confirmPassword = document.getElementById('confirmPassword').value.trim();
    if (confirmPassword !== password) {
        document.getElementById('confirmPasswordError').textContent = 'Passwords do not match';
        hasError = true;
        confirmPassword.innerHTML = '<i class="fas fa-check-circle"></i>';
    }

    // If no errors, form submission is successful
    if (!hasError) {
        alert('Registration successful!');
        form.reset();  // Reset form fields after successful validation
    }
});
